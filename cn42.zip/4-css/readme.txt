请下载 https://yishuai.github.io/js/cn-react1.zip，在本地练习。

1）安装node.js

网址：https://nodejs.org/en/download

安装完后，请在命令行执行下面的语句，观察结果，确保没有错误。

node -v
npm -v

2）解压zip文件，复习PPT文件，熟悉各文件的内容

3）在命令行，进入解压后的cn-react1目录，运行下面的语句，观察结果，确保没有错误。

npm install

注：会下载200M左右的代码到该目录下，存在一个叫node_modules的目录里。

4）还是在cn-react1目录下，运行下面的语句，观察结果，确保没有错误。

npm start

注：30秒左右，它会自动启动你的浏览器。你应该能够看到“你好！”这两个字。这就表示你的第一个React应用已经成功运行了。

5）参考课程PPT，修改文件，完成你的第一个React应用。它应该包含

a）一个p标签
b）一个图像
c）一条链接
d）你喜欢的另外3个标签！

6）请提交代码和浏览器最终的效果截屏到微信群里