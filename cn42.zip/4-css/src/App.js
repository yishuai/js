import React from "react";
import "./App.css";
import Dog from "./Dog.js";

export default function App() {
  return (
    <div>
      <h1> 猫之国 </h1>
      <p> 艾克你好！</p>
      <img style={{ width: 200 + "px" }} src="rose-flower.jpeg" alt="" />
      <p>
        <a href="http://yishuai.github.io">Link</a>
      </p>

      <Dog />
      <Dog />
      <Dog />
    </div>
  );
}
