import React from "react";
import "./App.css";

export default function Dog() {
  return (
    <div className="Dog">
      <img src="rose-flower.jpeg" />
      <p> 狗狗：我可爱吗？</p>
    </div>
  );
}
