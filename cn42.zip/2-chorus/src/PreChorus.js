import React from 'react';

function PreChorus()  {
    return (
      <div className="PreChorus">
          Its like Ive been awakened <br/>
          Every rule I had you breakin <br/>
          Its the risk that Im takin <br/>
          I aint never gonna shut you out <br/>
          <br/>
      </div>
    );
}

export default PreChorus;