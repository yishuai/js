import React from 'react';

function Chorus()  {
    return (
      <div className="Chorus">
        Everywhere Im lookin now <br/>
        Im surrounded by your embrace <br/>
        Baby, I can see your halo <br/>
        You know youre my savin grace <br/>
        Youre everything I need and more <br/>
        Its written all over your face <br/>
        Baby, I can feel your halo <br/>
        Pray it wont fade away <br/>
      </div>
    );
}

export default Chorus;