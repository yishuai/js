import React from "react";
import "./App.css";
import VerseOne from "./VerseOne.js";
import PreChorus from "./PreChorus.js";

//import he components above and call them below to finish the song. You will have to make the VerseTwo component. https://genius.com/Beyonce-halo-lyrics

function App() {
  return (
    <div className="App">
      <VerseOne />
      <PreChorus />
    </div>
  );
}

export default App;
