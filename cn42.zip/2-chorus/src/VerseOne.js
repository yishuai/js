import React from 'react';

function VerseOne()  {
    return (
      <div className="VerseOne">
          Remember those walls I built? <br/>
          Well, baby, theyre tumblin down <br/>
          And they didnt even put up a fight <br/>
          They didnt even make a sound <br/>
          I found a way to let you in <br/>
          But I never really had a doubt <br/>
          Standin in the light of your halo <br/>
          I got my angel now <br/>
          <br/>
      </div>
    );
}

export default VerseOne;