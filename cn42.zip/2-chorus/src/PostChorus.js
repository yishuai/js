import React from 'react';

function PostChorus()  {
    return (
      <div className="PostChorus">
        I can feel your halo, halo, halo <br/>
        I can see your halo, halo, halo <br/>
        I can feel your halo, halo, halo <br/>
        I can see your halo, halo <br/>
        Halo
        <br/>
      </div>
    );
}

export default PostChorus;