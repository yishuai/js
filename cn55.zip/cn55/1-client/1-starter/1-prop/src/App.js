import React, { Component } from 'react';
import './App.css';
import Question from './Question';


class App extends Component {

  render() {
    return (
      <div>
        <div className="appBar">
          Trivia App!
        </div>
        <div className="questionWrapper">
          <Question 
            questionText={"What is the meaning of life?"}/>
        </div>
      </div>
    );
  }
}

export default App;