import React, { Component } from 'react';
import '../css/App.css';
// import components

class App extends Component {

  render() {
    return (
      <div className="app">
        Trivia!
        
      </div>
    );
  }
}

export default App;