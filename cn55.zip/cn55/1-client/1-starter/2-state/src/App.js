import React, { Component } from 'react';
import './App.css';
import Question from './Question';


class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      currentQuestion: {
        questionText: "This is different",
        choices: ["a", "b", "c", "d"],
        correctChoiceIdx: 2,
      }
    };
  }

  render() {
    return (
      <div>
        <div className="appBar">
          Trivia App!
        </div>
        <div className="questionWrapper">
          <Question 
            questionText={this.state.currentQuestion.questionText}/>
        </div>
      </div>
    );
  }
}

export default App;