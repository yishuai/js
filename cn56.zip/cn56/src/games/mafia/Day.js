import React, { Component } from 'react';

export default class Day extends Component {
    
    render() {
        return (
        <div>
            Day
        </div>)
    }
    
}
