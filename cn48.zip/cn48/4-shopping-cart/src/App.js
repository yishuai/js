import React from "react";
import "./App.css";
import Item from "./Item.js";

export default function App() {
  // 1. 再添加3件商品到购物车
  // 2. 向每个项目添加一个项目说明
  // 3. 添加链接以在淘宝上购买商品
  return (
    <div>
      <h1>购物吧!</h1>
      <div className="Items">
        <Item
          url={
            "https://images.pexels.com/photos/67636/rose-blue-flower-rose-blooms-67636.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
          }
          name={"花"}
          price={100}
          description={"它是一朵美丽的花!"}
        />
      </div>
    </div>
  );
}
