import React, { Component } from 'react';
import "./FlagColor.css";

export default class FlagColor extends Component {

render() {
  const {color} = this.props
  const style = {backgroundColor : color};
    return (
      <div className="flag-color" style={style} >
      </div>
    );
  }

}