import React, { Component } from "react";
import "./App.css";
import Question from "./Question";

class App extends Component {
  render() {
    return (
      <div>
        <div className="appBar">请问！</div>
        <div className="questionWrapper">
          <Question questionText={"什么是生命的意义?"} />
        </div>
      </div>
    );
  }
}

export default App;
