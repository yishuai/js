import React from "react";

class SelectableButton extends React.Component {
  render() {
    if (this.props.selected) {
      return (
        <button style={{"background-color": "green"}} onClick={this.props.onClick}>
          {this.props.text}
        </button>);
    } else {
      return (<button onClick={this.props.onClick}>{this.props.text}</button>);
    }
  }
}

export default SelectableButton;
