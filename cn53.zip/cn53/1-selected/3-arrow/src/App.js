import React from 'react';
import './App.css';
import SelectableButton from "./SelectableButton";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selected: false
    }
  }
  handleClick() {
    this.setState({ selected: !this.state.selected });
  }
  render() {
    return (
    <SelectableButton onClick={this.handleClick} children={"Lorem Ipsum"} selected={this.state.selected}>
      
    </SelectableButton>
    )
  }
}

export default App;
