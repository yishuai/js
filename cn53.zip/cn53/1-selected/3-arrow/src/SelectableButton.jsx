import React from "react";

class SelectableButton extends React.Component {
  render() {
    return (<button>{this.props.selected}</button>);
    // if (this.props.selected) {
    //   return (
    //     <button style={{"background-color": "green"}}>
    //       {this.props.children}
    //     </button>);
    // } else {
    //   return (<button>{this.props.children}</button>);
    // }
  }
}

export default SelectableButton;
