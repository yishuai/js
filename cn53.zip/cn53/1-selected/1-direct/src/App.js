import React from 'react';
import './App.css';
import SelectableButton from "./SelectableButton";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selected: false
    }
  }
  
  render() {
    return (
    <SelectableButton children={"Lorem Ipsum"}>
    </SelectableButton>
    )
  }
}

export default App;
