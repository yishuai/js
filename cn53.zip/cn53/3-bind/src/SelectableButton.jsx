import React from "react";

class SelectableButton extends React.Component {
  render() {
    // return (<button>{this.props.selected}</button>);

    if (this.props.selected) {
      return (
        // <button style={{"backgroundColor": "green"}} onClick = {() => this.props.onClick()}>
        <button style={{"backgroundColor": "green"}} onClick = {this.props.onClick}>
          {this.props.children}
        </button>);
    } else {
      return (
      // <button onClick = {() => this.props.onClick()}>
      <button onClick = {this.props.onClick}>
        {this.props.children}</button>);
    }
  }
}

export default SelectableButton;
