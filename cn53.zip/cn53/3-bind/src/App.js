import React from 'react';
import './App.css';
import SelectableButton from "./SelectableButton";

class App extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      selected: false
    }
    // 在 JavaScript 中，class 的方法默认不会绑定 this。
    // 如果你忘记绑定 this.handleClick 并把它传入了 onClick
    // 当你调用这个函数的时候 this 的值为 undefined。

    // 这并不是 React 特有的行为；这其实与 JavaScript 函数工作原理有关。
    // 通常情况下，如果你没有在方法后面添加 ()，例如 onClick={this.handleClick}，你应该为这个方法绑定 （bind） this。

    this.handleClick = this.handleClick.bind(this);
  }

  handleClick() {
    this.setState({ selected: !this.state.selected });
  }

  render() {
    return (
    <SelectableButton onClick={this.handleClick} children={"Lorem Ipsum"} selected={this.state.selected} />
    )
  }
}

export default App;
