import React from "react";

class SelectableButton extends React.Component {
  
  handleClick() {
    this.setState({ selected: !this.state.selected });
  }
  render() {
    if (this.state.selected) {
      return (
        <button style={{"background-color": "green"}} onClick={() => this.handleClick()}>
          {this.props.children}
        </button>);
    } else {
      return (<button onClick={() => this.handleClick()}>{this.props.children}</button>);
    }
  }
}

export default SelectableButton;
