＃3.2 CSS 多个规则

更改页面上的元素，为您最喜欢的艺术家做一副最漂亮的海报。这包括：

1）修改 CSS，选择至少 5 种不同的 CSS 属性和值来设置 html 元素的样式。

2）修改 HTML，添加指向该歌手最佳歌曲的视频的链接。

3）修改 CSS，使用“:hover”选择器，看看您可以用它做什么！

4）尝试下面这些 CSS 属性！看看他们在做什么？

- text-decoration (underline, overline, line-through)
- text-align (center, left, right)
