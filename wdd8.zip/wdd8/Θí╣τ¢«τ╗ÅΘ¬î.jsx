// 1、基本步骤
// npx create-react-app demo-app
// cd demo-app
// npm install react-router-dom
// API：https://reactrouter.com/web/api





// 2、基本使用（5.x版本）
// （1）basic
{/* <Router>
  <Link to="/">home</Link>
  <Link to="/about">about</Link>

  <Switch>
    <Route exact path="/">
      <Home />
    </Route>
    <Route path="/about">
      <About />
    </Route>
  </Switch>
</Router> */}
// 另一种写法
{/* <Router>
  <Link to="/about">about</Link>
  <Link to="/inbox">inbox</Link>

  <Switch>
    <Route exact path="/inbox" children={<Inbox />} />
    <Route path="/about" children={<About />} />
  </Switch>
</Router> */}








// （2）url parameters
/*  /:id 匹配任意以 / 开头的url
/home --> id:"home"
/home/about --> id:"home"
/login/home --> id:"login"
*/
/*  /home/:id 匹配任意以 /home/ 开头的url
/home/about --> id:"about"
/about --> id:""
*/
{/* <Router>
  <Link to="/home/netflix">Netflix</Link>
  <Link to="/zillow-group">Zillow Group</Link>

  <Switch>
    <Route path="/:id" children={<Child />} />
  </Switch>
</Router>

function Child() {
  let { id } = useParams();
  return (
    <div>
      <h3>ID: {id}</h3>
    </div>
  );
} */}
// 注意：这里/:id可以任意写，如/:myid，那么从useParams里取到的就是myid








// （3）nesting
// 补充：关于url和path，https://blog.csdn.net/weixin_34038293/article/details/85186339
//      在嵌套式<Link>组件中尽量使用match.url，而在嵌套式<Route>组件中尽量使用match.path，即下例中的path和url
// 例子如下：
{/*
import React from 'react';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  useParams,
  useRouteMatch
} from 'react-router-dom';


function App() {
  return (
    <Router>
      <Link to="/home">Home</Link><br/>
      <Link to="/topics">Topics</Link>
      <hr/>

      <Switch>
        <Route exact path="/home" children={<Home />} />
        <Route path="/topics" children={<Topics />} />
      </Switch>
    </Router>
  );
}

function Home() {
  return (
    <div>
      <h2>Home</h2>
    </div>
  );
}

function Topics() {
  let {url, path} = useRouteMatch();  // 这里url和path都是'/topics'
  return (
    <div>
      <h2>Topics</h2><br/>
      <Link to={`${url}/education`}>education</Link><br/>
      <Link to={`${url}/sport`}>sport</Link><br/>
      <hr/>

      <Switch>
        <Route exact path={path}>
          请选择topic
        </Route>
        <Route path={`${path}/:topicId`} children={<Child />} />
      </Switch>
    </div>
  );
}

function Child() {
  let { topicId } = useParams();
  return (
    <div>
      topic: {topicId}
    </div>
  );
}

export default App;
*/}








// （4）redirect
/* useHistory
// 使用useHistory可以用于访问历史（导航栏常用）
import { useHistory } from "react-router-dom";

function HomeButton() {
  let history = useHistory();  // 访问记录

  function handleClick() {
    history.push("/home");
  }

  return (
    <button type="button" onClick={handleClick}>
      Go home
    </button>
  );
}
*/
/* useLocation
import React from "react";
import ReactDOM from "react-dom";
import {
  BrowserRouter as Router,
  Switch,
  useLocation
} from "react-router-dom";

function usePageViews() {
  let location = useLocation();
  React.useEffect(() => {  // 首次渲染和重新渲染时都会执行传入的函数（副作用函数）
    ga.send(["pageview", location.pathname]);
  }, [location]);  // 告诉react只有当location的值变化时，才执行副作用函数
}

function App() {
  usePageViews();
  return <Switch>...</Switch>;
}

ReactDOM.render(
  <Router>
    <App />
  </Router>,
  node
);
*/
/* Route的render、children和component
https://blog.csdn.net/boale_h/article/details/109069658
在使用Route的这三个属性渲染组件时还有一点值得注意，就是当这三个属性同时存在时的优先级问题，
正常情况下我们基本上使用其中一个属性就可以了，但当他们同时存在时，优先渲染component的值，
其次是render属性的值，而children属性的值优先级最低，为了避免 不必要的错误，尽量每个Route中只是用他们三个中的其中一个
*/
// 例子
// import React, { useContext, createContext, useState } from "react";
// import {
//   BrowserRouter as Router,
//   Switch,
//   Route,
//   Link,
//   Redirect,
//   useHistory,
//   useLocation
// } from "react-router-dom";

// export default function AuthExample() {
//   return (
//     <ProvideAuth>  {/* 这里是一个插槽，ProvideAuth包裹的内容，被传到了ProvideAuth组件的props.children（数组）里 */}
//       <Router>
//         <div>
//           <AuthButton />

//           <ul>
//             <li>
//               <Link to="/public">Public Page</Link>
//             </li>
//             <li>
//               <Link to="/protected">Protected Page</Link>
//             </li>
//           </ul>

//           <Switch>
//             <Route path="/public">
//               <PublicPage />
//             </Route>
//             <Route path="/login">
//               <LoginPage />
//             </Route>
//             <PrivateRoute path="/protected">  {/* 这也是一个插槽 */}
//               <ProtectedPage />
//             </PrivateRoute>
//           </Switch>
//         </div>
//       </Router>
//     </ProvideAuth>
//   );
// }

// const fakeAuth = {
//   isAuthenticated: false,
//   signin(cb) {
//     fakeAuth.isAuthenticated = true;
//     setTimeout(cb, 100);  // 100ms以后执行cb，即使user="user"
//   },
//   signout(cb) {
//     fakeAuth.isAuthenticated = false;
//     setTimeout(cb, 100);  // 100ms以后执行cb，即使user=null
//   }
// };


// const authContext = createContext();

// function ProvideAuth({ children }) {  // 最外层组件，它的子组件通过authContext.Provider共享状态auth
//   const auth = useProvideAuth();  // auth = {user, signin, signout} 
//                                   // signin为函数，作用是使user为"user"，使fakeAuth.isAuthenticated为true
//                                   // signout也是函数，作用是使user为null，使fakeAuth.isAuthenticated为false
//   return (
//     <authContext.Provider value={auth}>
//       {children}
//     </authContext.Provider>
//   );
// }

// function useAuth() {
//   return useContext(authContext);  // useContext(authContext)返回共享状态auth
// }

// function useProvideAuth() {
//   const [user, setUser] = useState(null);  

//   const signin = cb => {
//     return fakeAuth.signin(() => {
//       setUser("user");
//       cb();
//     });
//   };

//   const signout = cb => {
//     return fakeAuth.signout(() => {
//       setUser(null);
//       cb();
//     });
//   };

//   return {
//     user,
//     signin,
//     signout
//   };
// }

// function AuthButton() {
//   let history = useHistory();
//   let auth = useAuth();  // 获取共享状态

//   return auth.user ? (  // user为null或"user"
//     <p>
//       Welcome!{" "}
//       <button
//         onClick={() => {
//           auth.signout(() => history.push("/"));
//         }}
//       >
//         Sign out
//       </button>
//     </p>
//   ) : (
//     <p>You are not logged in.</p>
//   );
// }

// // PrivateRoute是一个高阶组件，对Route组件进行了封装
// function PrivateRoute({ children, ...rest }) {  // children是<ProtectedPage />
//   let auth = useAuth();
//   return (
//     <Route  // 组件中包含Redirect就可以实现重定向，会自动修改url为Redirect里的to
//       {...rest}  // 解构rest，里面有location
//       render={({ location }) =>  // Route标签的三个互斥属性：render、component、children
//         auth.user ? (
//           children  // 如果auth.user为true，就渲染<ProtectedPage />
//         ) : (
//           <Redirect  // 如果auth.user为false，就渲染Redirect，重定向到登入页面
//             to={{
//               pathname: "/login",
//               state: { from: location }
//             }}
//           />
//         )
//       }
//     />
//   );
// }

// function PublicPage() {
//   return <h3>Public</h3>;
// }

// function ProtectedPage() {
//   return <h3>Protected</h3>;
// }

// function LoginPage() {
//   let history = useHistory();
//   let location = useLocation();
//   let auth = useAuth();

//   let { from } = location.state || { from: { pathname: "/" } };
//   let login = () => {
//     auth.signin(() => {
//       history.replace(from);
//     });
//   };

//   return (
//     <div>
//       <p>You must log in to view the page at {from.pathname}</p>
//       <button onClick={login}>Log in</button>
//     </div>
//   );
// }
