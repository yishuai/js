import React from "react";
import ReactDOM from "react-dom";
import AppRouter from "./router";

import "./styles.css";

function App() {
  return (
    <div className="App">
      <AppRouter />
    </div>
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
