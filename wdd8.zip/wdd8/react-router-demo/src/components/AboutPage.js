import React from "react";

export default class AboutPage extends React.Component {
  render() {
    return (
      <div>
        <h1>This is the About Page!</h1>
        <p>This is some random text on the about page.</p>
      </div>
    );
  }
}
