import React from "react";

export default class ContactPage extends React.Component {
  render() {
    return (
      <div>
        <h1>This is the Contact Page!</h1>
        <p>This is some random text on the contact page.</p>
      </div>
    );
  }
}
