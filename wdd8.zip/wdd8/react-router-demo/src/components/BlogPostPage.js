import React from "react";

export default class BlogPostPage extends React.Component {
  render() {
    let id = this.props.match.params.id;
    return (
      <div>
        <h1>You are reading Blog Post {id}</h1>
        <p>This is some random text on the blog post page.</p>
        <p>
          The ID for this blog post was taken from the url! Try changing it to
          `/blog/hello`
        </p>
      </div>
    );
  }
}
