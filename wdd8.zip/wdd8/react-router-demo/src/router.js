import React from "react";
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import AboutPage from "./components/AboutPage";
import HomePage from "./components/HomePage";
import ContactPage from "./components/ContactPage";
import BlogPostPage from "./components/BlogPostPage";

function AppRouter() {
  return (
    <Router>
      <div>
        <nav>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/about/">About</Link>
            </li>
            <li>
              <Link to="/contact/">Contact</Link>
            </li>
            <li>
              <Link to="/blog/1">Blog Post 1</Link>
            </li>
            <li>
              <Link to="/blog/2">Blog Post 2</Link>
            </li>
          </ul>
        </nav>

        <Route path="/" exact component={HomePage} />
        <Route path="/about/" component={AboutPage} />
        <Route path="/contact/" component={ContactPage} />
        <Route path="/blog/:id" component={BlogPostPage} />
      </div>
    </Router>
  );
}

export default AppRouter;
