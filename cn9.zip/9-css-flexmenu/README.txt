使用Flexbox和Box模型，用三种不同的方式，设计导航栏！每个菜单项都必须相邻放置。

要求：

1）添加CSS样式，每种导航栏，使用不同的flexbox方式，例如“justify-content”，“border”，“padding”，“margin”，“font-color”，“background-color”，等等

2）尝试以下“父元素”的设置
align-items
align-content
flex-wrap

3）尝试以下“子元素”的设置
flex
order
align-self

若有问题，请使用百度、Bing、Google、W3school.cn （https://www.w3school.com.cn），搜索答案

请提交网站URL

