import React, { Component } from 'react';
import './App.css';

class App extends Component {

  handleClick2(){
    alert('this is different');
  }

  handleClick() {
    alert('clicked!');
  }

  render() {
    return (
      <div className="App">
        <button onClick={() => this.handleClick2()}>
        Click Me
        </button>
      </div>
    );
  }
}

export default App;
