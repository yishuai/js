import React from 'react';
import Cat from './Cat.js';
import './App.css'

export default function App() {
   
  return (
	<div>
     		<h1> Pet Shop </h1>
      	<Cat 
          url={"https://image.shutterstock.com/image-photo/kitty-stands-on-pink-background-260nw-1009056685.jpg"}
          name={"Tiny"}
        />
	</div>
   )
}
