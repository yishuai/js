import React from 'react';

export default function Cat(props) {
   
  function meow(){
    alert("Meow!");
  }
  // 在下面的注释下方分别添加对应的函数
  // 1. Alert "prrrr" on onMouseOver

  // 2. Alert "Hiss" on onDoubleClick
  
  // 3. Alert 你的信息 on onMouseLeave

  return (
    <div 
      onClick={meow} 
      onMouseOver
      className="Cat"
    >
      <img src={props.url}/>
      <p> Name: {props.name} </p>
    </div>
   )
}
