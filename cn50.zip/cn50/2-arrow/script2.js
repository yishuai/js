let sum = function (val1, val2) {
  return val1 + val2;
}



let average = function (val1, val2, val3, val4) {
  let sum = val1 + val2 + val3 + val4;
  return sum/4;
}

let countIsInString = function (string) {
  let count = 0;
  for (let i = 0; i < string.length; i++){
    if (string[i] === 'i') {
      count++;
    }
  }
  return count;
}