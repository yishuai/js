let add = function(a, b) {
  return a+b;
}

let addArrowFunction;

let distance = function(x1, y1, x2, y2) {
  let xDiff = Math.pow(x2 - x1, 2);
  let yDiff = Math.pow(y2 - y1, 2);
  return Math.sqrt(xDiff + yDiff);
}

let distanceArrowFunction;

let compareNumbers = function(a, b) {
  if (a > b) {
    return 1;
  } else if (a < b){
    return -1;
  } else {
    return 0;
  }
}

let compareNumbersArrowFunction;

let findSecondLargest = function(numList) {
  let sortedList = numList.sort(function(a,b) {
    return compareNumbers(a,b);
  });
  console.log(sortedList);
  return sortedList[sortedList.length - 2];
}
findSecondLargest([-9, -23423, -12, 0]);


let findSecondLargestArrowFunction;