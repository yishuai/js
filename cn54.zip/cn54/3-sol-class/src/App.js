import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Question from './Question.js';

class App extends Component {
  constructor(props){
    super(props);

    this.state = {
      questions: [
        {question: "test", answer: "eset"}
      ],
    }
  }
  
  render() {
    return (
      <div className="App">
          <h1>Jeopardy</h1>
          <div className="questions">
            {
              this.state.questions.map(
                (question)=> 
                <Question 
                  answer={question.answer}
                  question={question.question}
                />
              )
            }
          </div>
      </div>
    );
  }
}

export default App;
