import React, { Component } from 'react';
import './Question.css';

class Question extends Component {
  constructor(props){
    super(props);
    this.state = {
      showAnswer: false,
    }
  }
  
  showAnswer(){
    this.setState({showAnswer: !this.state.showAnswer});
  }

  render() {
    let display;
    if(this.state.showAnswer){
      display = this.props.answer;
    } else {
      display = this.props.question;
    }
    
    return (
      <div className="question" onClick={()=>this.showAnswer()}>
          {display}
      </div>
    );
  }
}

export default Question;
