import React from 'react';
import './LogIn.css';

export default class LogIn extends React.Component {
  constructor() {
    super();
    this.state = {
      userName: null,
      countButtonClick : 0
    }
  }
  LogInUser = () => {
   // this.setState({userName:'Chris'});
   
    this.setState(oldState => ({userName:'Chris',
    countButtonClick:++oldState.countButtonClick}));
    
  }
  render() {
    return (
      <div>
      <div> {this.props.welcomeMessage} {this.state.userName}! </div>
        <button onClick={this.LogInUser}> Log In </button>
       <div>
       You've clicked this button : {this.state.countButtonClick} times
       </div>
      
      </div>
    );
  }
}