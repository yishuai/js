import React from 'react';
import LogIn from "./components/LogIn/LogIn.js";
import './App.css';

export default class App extends React.Component {
  render() {
    return (
    <div>
       
      <LogIn welcomeMessage="Hola" />
        
      </div>
    );
  }
}