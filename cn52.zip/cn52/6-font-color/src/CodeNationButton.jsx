import React from "react";

class CodeNationButton extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      disabled: false,
      click_count: 0
    };
  }

  handleClick() {
    var new_click_count = this.state.click_count + 1;
    let font_color = "green";
    if (new_click_count > 4) {
      font_color = "red";
    }
    this.setState({
      click_count: new_click_count,
      font_color: font_color
    });
  }

  render() {
    return (
      <button onClick={() => this.handleClick()} disabled={this.state.disabled}>
        <font color={this.state.font_color}>
          Click Number {this.state.click_count}
        </font>
      </button>
    );
  }
}

export default CodeNationButton;
