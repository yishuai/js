import React, { Component } from 'react';

import './App.css';
import CodeNationButton from './CodeNationButton';

class App extends Component {
  render () {
    return (
    <div className="App">
      <CodeNationButton />
    </div>
    );
  } 
}

export default App;
