import React, { Component } from 'react';
import './App.css';
import Click from './Click.js';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      numClicks: 0,
      classes: 'app',
    };
  }

  handleClick(e) {
    const newClicks = this.state.numClicks + 1;
    this.setState({
      numClicks: newClicks,
      classes: this.genClassList(newClicks),
    });
  }

  genClassList(newClicks) {
    let classList = 'app ';
    if (newClicks % 10 === 0) {
      classList += 'ten';
    } else if (newClicks % 9 === 0) {
      classList += 'nine';
    } else if (newClicks % 8 === 0) {
      classList += 'eight';
    } else if (newClicks % 7 === 0) {
      classList += 'seven';
    } else if (newClicks % 6 === 0) {
      classList += 'six';
    } else if (newClicks % 5 === 0) {
      classList += 'five';
    } else if (newClicks % 4 === 0) {
      classList += 'four';
    } else if (newClicks % 3 === 0) {
      classList += 'three';
    } else if (newClicks % 2 === 0) {
      classList += 'two';
    } else {
      classList += 'prime';
    }
    return classList;
  }

  render() {
    return (
      <div
        className={this.state.classes}
        onClick={(e) => this.handleClick(e)}>
        <Click count={this.state.numClicks} />
      </div>
    );
  }
}

export default App;
