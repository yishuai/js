// eslint-disable-next-line
import React, { Component } from 'react';
import './Click.css';

function Click (props) {
  return (
    <div className="counter">
      {props.count}
    </div>
  );
}

export default Click;
