＃for循环-复仇者联盟：课程战争

宇宙需要您的帮助！利用您对“for of”循环的了解，召唤银河系最强大的英雄与邪恶的Thanos战斗！

请访问 https://popcode.org/?snapshot=3555d56c-9a81-455e-8d81-00bbde47055d，或下载 cn23.zip，修改里面的Javascript代码。

1）在提供的click处理程序中，编写for循环，该循环将遍历avengerPics数组并显示每个图像。

2）将其他图像添加到您最喜欢的超级英雄的`avengerPics`数组中！它们是不是会自动显示在网页上？

3）使用复仇者联盟的名称创建一个名为avengerNames的新数组，创建一个新的for循环，遍历该数组，在<p>标签中显示每个名称

请提交你网页的URL