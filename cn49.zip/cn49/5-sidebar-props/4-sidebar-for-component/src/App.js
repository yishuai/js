import React from 'react';
import Header from "./components/Header/Header.js";
import Main from "./components/Main/Main.js";
import Sidebar from "./components/Sidebar/Sidebar.js";
import './App.css';

function  {
  render() {
    return (
    <div>
       <div className="app">
        <div className="app-header">
          <Header/>
        </div>
        <div className="app-body">
          <Sidebar titles={["Hello", "Bye"]} />
          <Main/>
        </div>
      </div>
        
      </div>
    );
  }
}