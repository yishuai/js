import React from 'react';
import './Main.css';

export default class Main extends React.Component {
  render() {
    return (
      <div className="main">
        <h1>Main</h1>
      </div>
    );
  }
}