import React from 'react';
import './Sidebar.css';
import SidebarItem from '../SidebarItem/SidebarItem.js';

export default class Sidebar extends React.Component {
  render() {
   const titles=["Music", "Movies", "Candy", "Games"];

    let titlesHTML=[];
    for(let i=0; i<titles.length; i++) {
      titlesHTML.push(<SidebarItem title={titles[i]}  />);
    }
    return (
      <div className="sidebar">
        {titlesHTML}

      </div>
    );  
  }
}