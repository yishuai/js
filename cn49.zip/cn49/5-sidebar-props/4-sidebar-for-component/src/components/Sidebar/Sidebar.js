import React from 'react';
import './Sidebar.css';
import SidebarItem from '../SidebarItem/SidebarItem.js';

export default class Sidebar extends React.Component {
  render() {
   // const titles=["Music", "Movies", "Candy"];

    let titlesHTML=[];
    for(let i=0; i<this.props.titles.length; i++) {
      titlesHTML.push(<SidebarItem title={this.props.titles[i]}  />);
    }
    return (
      <div className="sidebar">
        {titlesHTML}

      </div>
    );  
  }
}