import React from 'react';
import './SidebarItem.css';

export default class SidebarItem extends React.Component {
  render() {
    const {title} = this.props;
    return (
      <div className="sidebar-item">
        {this.props.title}
        {this.props.sadness}
      </div>
    );
  }
}