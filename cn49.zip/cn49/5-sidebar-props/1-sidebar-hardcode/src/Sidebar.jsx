import React from 'react';
import './Sidebar.css';
import SidebarItem from './SidebarItem.jsx';

class Sidebar extends React.Component {
  render() {
    return (
      <div className="sidebar">
        <SidebarItem name={"Sidebar 1"}/>
        <SidebarItem name={"Sidebar 2"}/>
        <SidebarItem name={"Home"}/>
        <SidebarItem name={"Alejandro"}/>
        <SidebarItem name={"Settings"}/>
        <SidebarItem name={"Trending"}/>
        <SidebarItem name={"Info"}/>
      </div>
    );
  }
}

export default Sidebar;