import React from 'react';
import './SidebarItem.css';

class SidebarItem extends React.Component {
  render() {
    return (
      <div className="sidebar-item">
        {this.props.name}
      </div>
    );
  }
}

export default SidebarItem;