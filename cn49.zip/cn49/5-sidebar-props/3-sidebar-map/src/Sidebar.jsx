import React from 'react';
import './Sidebar.css';
import SidebarItem from './SidebarItem.jsx';

var items = ["Home", "Trending", "History", "Music"];

class Sidebar extends React.Component {
  render() {
    var s_items = items.map(function(title,index) {  
      return (
        <SidebarItem title={title} />
      );
    });
    return (
      <div className="sidebar">
        {s_items}
      </div>
    );  
  }
}

export default Sidebar;