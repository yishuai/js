import React from 'react';
import './App.css';
import Header from './Header.jsx';
import Main from './Main.jsx';
import Sidebar from './Sidebar.jsx';

class App extends React.Component {
  render() {
    return (
      <div className="app">
        <div className="app-header">
          <Header/>
        </div>
        <div className="app-body">
          <Sidebar/>
          <Main/>
        </div>
      </div>
    );
  }
}
export default App;
