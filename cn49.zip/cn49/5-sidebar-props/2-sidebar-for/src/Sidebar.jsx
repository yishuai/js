import React from 'react';
import './Sidebar.css';
import SidebarItem from './SidebarItem.jsx';

var items = ["Home", "Trending", "History", "Music"];

class Sidebar extends React.Component {
  render() {
    var s_items = [];
    for (var i in items) {
      s_items.push(<SidebarItem title={items[i]} />);
    }
    return (
      <div className="sidebar">
        {s_items}
      </div>
    );  
  }
}

export default Sidebar;