import React from 'react';
import './WeatherDay.css';

export default class Day extends React.Component {
  render() {
    return (
      <div className="day">
       <div> {this.props.day} </div>
        <div> <img src="https://image.shutterstock.com/image-vector/sun-icon-600w-411668686.jpg" height="100" /> </div>
        <div className="hi">{this.props.hi} </div>
        <div className="low"> {this.props.low} </div>
      </div>
    );
  }
}