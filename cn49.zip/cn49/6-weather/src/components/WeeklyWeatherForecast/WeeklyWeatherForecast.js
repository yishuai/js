import React, {Component} from 'react';
import WeatherDay from "../WeatherDay/WeatherDay";
import './WeeklyWeatherForecast.css';

export default class WeeklyWeatherForecast extends Component {
  render() {
    //loop through this.props.weeklyWeather instead!
    let weatherDays = [];
    for (let i=0; i< this.props.weeklyWeather.length; i++) {
      let weatherDay = this.props.weeklyWeather[i];
      let day = weatherDay.day;
      let hi = weatherDay.hi;
      let low = weatherDay.low;
      weatherDays.push(<WeatherDay day={day} hi={hi} low={low}/>);
    }
    return (
      <div className="weeklyWeatherForecast">
       {weatherDays}
      </div>
    );
  }
}
export const Chris = 'Chris';