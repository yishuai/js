import React, {Component} from 'react';
import Joe from "./components/WeeklyWeatherForecast/WeeklyWeatherForecast.js";
import './App.css';

export default class App extends Component  {
  render() {
    return (
    <div>
       
      <Joe weeklyWeather={
        [
          {day:'Sunday',
            hi:80,
          low:55},
          {day:'Monday',
            hi:64,
          low:50},
          {day:'Tuedays',
            hi:75,
          low:50},
          {day:'Wednesday',
            hi:70,
            low:50},
          {day:'Thursday',
            hi:75,
            low:55},
         {day:'Friday',
            hi:90,
            low:55},
          {day:'Saturday',
            hi:105,
            low:80}, 
        ]
      } />
        
      </div>
    );
  }
}