$(document).ready(function() {
	const distanceToNextImage = -450;
	let currentImageNumber = 0;

	// 您的代码在这里


	// 其他代码
	// 单击叠加层或x时，关闭灯箱
	$("#overlay, #close").click(function() {
		$("#lightbox").hide();
	})
});