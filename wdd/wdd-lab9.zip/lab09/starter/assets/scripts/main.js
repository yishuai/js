
// 通常我们不会这样做，但是使画布和上下文在全局范围内可用更容易进行动手操作。
let canvas, context, hueSlider;

// Step 3 Part 1/3
// 让我们做一个计数器count并将其值初始化为0





/**
 * 在页面成功加载后，应运行的处理函数
 * 浏览器完成页面的源代码读取后，我们才使用document.getElementById（）
 */
function pageLoaded() {

    // 获取canvas画布和2D绘图上下文
    canvas = document.getElementById("canvas");
    context = canvas.getContext("2d");

    // 获取色调hue滑块slider元素
    hueSlider = document.getElementById("hue-slider");

    //
    // 鼠标移动时...
    //

    /**
     * @param {MouseEvent} event
     */
    function mouseMoved(event) {
        // Step 3 Part 2/3
        // 每次鼠标移动时，我们会将计数器的值增加一





        // Step 1
        // 让我们在鼠标光标的位置用fillCircle（）或strokeCircle（）画一个圆！
        // 当用户将鼠标移到画布上时，浏览器将运行此函数。
        // 带一个鼠标事件，包含鼠标的位置信息。

        // 您可以从event.clientX和event.clientY获取鼠标的位置-它们是X，Y坐标编号，它们与鼠标在屏幕上的位置相对应。

        // 也许首先尝试用console.log（）打印这两个值并观察（0,0）在页面上的位置
        // 由于此函数每次在页面上移动鼠标时都会运行，因此该函数中的console.log（）也将多次运行
        fillCircle(event.clientX, event.clientY);




        // 对于第3步第3/3部分，您将修改为第1步编写的代码
        // 完成步骤3的第1部分和第2部分后，请检查上面的radiusFunction（）！
        // 除了用恒定的半径绘制圆，我们可以使其半径随位置和时间而变化





    }

    // 当鼠标在画布上移动时，让浏览器运行mouseMoved（）
    canvas.onmousemove = mouseMoved;

    //
    // 当用户操作滑动条时...
    //

    /**
     * 调整滑动条时运行的处理程序
     */
    function hueChanged() {
        // 步骤2的1/3
        //在index.html中，滑块的值范围是0到359
        // 让我们将滑块的值存储在一个变量中，比如一个叫“hue”的变量





        // 步骤2第2/3部分
        // 由于在JavaScript中设置CSS属性的值遵循相同的格式，因此让我们看一下hsl（色相，饱和度，亮度）颜色格式 https://developer.mozilla.org/en-US/docs/Web/CSS/color_value
        // 然后用颜色hsl（hue，100％，50％）设置context.fillStyle和context.strokeStyle，使其具有100％的饱和度和50％的亮度（你也可以改）

        // 如果hue等于100，则可能看起来像这样。
        // （我们如何使此操作适用于hue变量的任何值？）

        // context.fillStyle = 'hsl(300, 100%, 50%)';




    }

    // 步骤2第3/3部分
    // 设置hueSlider的属性，在我们更改滑块时，浏览器会为我们运行hueChanged（）
    // 为此，您需要将hueSlider的onchange属性设置为hueChanged函数（就像我们前面设置onclick函数一样）





    //
    // 窗口调整大小时...
    //

    /**
     * 每次调整窗口大小时运行的处理程序
     */
    function windowResized() {
        // 设置画布的宽度/高度时，将清除图形
        canvas.width = canvas.offsetWidth;
        canvas.height = canvas.offsetHeight;

        // 我们因此手动触发hueChanged，因为填充/描边颜色被清除了
        hueChanged();
    }

    // 当窗口大小更改时，我们让浏览器为我们运行windowResized（）
    window.onresize = windowResized;
    // 然后我们手动触发windowResized函数
    windowResized();

}

// 当页面加载时，我们让浏览器为我们运行pageLoaded（）
window.onload = pageLoaded;

//
// 给定位置“ x”，“ y”和“ t”（时间），返回半径等的几个函数
//

/**
 * 给定位置和时间，返回一个半径
 *
 * @param {number} x
 * @param {number} y
 * @param {number} t
 */
function radiusFunction1(x, y, t) {
    return 20 * Math.abs(Math.sin(t / 100 * Math.PI));
}

/**
 * 给定位置和时间，返回一个半径（一个随机数）
 *
 * @param {number} x
 * @param {number} y
 * @param {number} t
 */
function radiusFunction2(x, y, t) {
    return 20 * Math.random();
}

/**
 * 给定位置和时间，返回一个半径
 *
 * @param {number} x
 * @param {number} y
 * @param {number} t
 */
function radiusFunction3(x, y, t) {
    return t % 50;
}

/**
 * 给定位置和时间，返回一个半径
 *
 * @param {number} x
 * @param {number} y
 * @param {number} t
 */
function radiusFunction4(x, y, t) {
    return 20 * Math.abs(Math.sin(x / 100 * Math.PI) * Math.sin(y / 100 * Math.PI));
}
