import React from 'react';
import './App.css';

function nameList() {

}

export default function App() {
  const [names, setNames] = React.useState([]);
  const [header, setHeader] = React.useState('Names');

  // 在函数组件内部使用 ref 属性，只要它指向一个 DOM 元素或 class 组件
  // 声明 inputRef ref ， 然后在下面把它指向 input
  // 然后可以在 inputRef.current 中访问这个 DOM

  const inputRef = React.useRef();
  const headerInputRef = React.useRef();

  return (
    <div>
      <p>
        Add a name:
        <input ref={inputRef} />
      </p>
      <p>
        <button onClick={
          () => {
            setNames(
              [...names, inputRef.current.value]
            );
          }
        }>加</button>
      </p>
      <p>
        Update the header:
        <input ref={headerInputRef} />
        <button onClick={
          () => {
            setHeader(headerInputRef.current.value);
          }
        }>Update</button>
      </p>
      <h1>{header}</h1>
      <p>
        <ul>
          {
            names.map((name) => <li>{name}</li>)
          }
        </ul>
      </p>
    </div>
  );
}
