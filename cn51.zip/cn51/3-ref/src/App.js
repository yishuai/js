import React from 'react';
import './App.css';

function nameList() {
  
}

export default function App() {
  const [names, setNames] = React.useState([]);
  const [header, setHeader] = React.useState('Names');
  const inputRef = React.useRef();
  const headerInputRef = React.useRef();

  return (
    <>
    <p>
    Add a name:
    <input ref={inputRef} />
    </p>
    <p>
    <button onClick={
      () => {
        setNames(
          [...names, inputRef.current.value]
        );
      }
    }>Add</button>
    </p>
    <p>
    Update the header:
    <input ref={headerInputRef} />
    <button onClick={
      () => {
        setHeader(headerInputRef.current.value);
      }
    }>Update</button>
    </p>
    <h1>{header}</h1>
    <p>
      <ul>
        {
          names.map((name) => <li>{name}</li>)
        }
      </ul>
    </p>
    </>
  );
}
