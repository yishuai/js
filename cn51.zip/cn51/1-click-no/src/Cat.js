import React, { useState } from "react";

export default function Cat(props) {
  let [numPets, setNumPets] = useState(0);

  function pet() {
    setNumPets(numPets + 1);
  }

  return (
    <div onClick={pet} className="Cat">
      <img src={props.url} />
      <p> {props.name}：点我！</p>
      <p> {numPets} 次</p>
    </div>
  );
}
