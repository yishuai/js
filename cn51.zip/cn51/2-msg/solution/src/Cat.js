import React, { useState, useEffect } from "react";

// 创建一个新的状态变量message，给它一个初值”Meow”
// 在屏幕上显示这个状态变量
// Create function setMessage in state
// 创建一个状态函数setMessage
// 当用户点击触发pet函数时
// 使状态numPets加一
// 如果numPets大于3，更改状态message为”prrr”
// 如果numPets大于4，更改状态message为”growl”
// 如果numPets大于5，更改状态message为”hiss”

export default function Cat(props) {
  let [numPets, setNumPets] = useState(0);
  // 请创建状态变量message
  let [message, setmsg] = useState("Meow");

  // 下面的代码，更新msg 不及时。因为 setNumPets 是异步的
  // function pet(){
	//   setNumPets(numPets +1)
  //   setMessage()
  // }

// 采用 useEffect 来根据最新的 numPets 更新 message
// useEffect 在第一次渲染后和每次DOM更新之后都会执行 setMessage

useEffect(() => {
    setMessage();
  }, [numPets]);

function pet(){
  setNumPets(numPets +1)
}

  // 第二个参数 [numPets] 的作用:
  // 组件重渲染时，如果 numPets 没变，会跳过这个 effect，这就优化了性能
  //    https://zh-hans.reactjs.org/docs/hooks-effect.html

  function setMessage()
  {
    if (numPets > 3) {
      setmsg("prrr");
    }
    if (numPets > 4) {
      setmsg("growl");
    }
    if (numPets > 5) {
      setmsg("hiss")
    }
  }

  return (
    <div onClick={pet}>
      <p> Name: {props.name} </p>
      <p> {numPets} </p>
      <p>{message}</p>
    </div>
   )

}
