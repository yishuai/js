import React, { useState } from "react";

export default function Cat(props) {
  let [numPets, setNumPets] = useState(0);
  // 请创建状态变量message
  
  function pet(){
	  setNumPets(numPets +1);
  }

  function setMessage() {
    // 请完成课堂练习
  }

  return (
    <div onClick={pet}>
      <p> Name: {props.name} </p>
      <p> {numPets} </p>
      {/* 请显示状态变量message */}
    </div>
   )

}
